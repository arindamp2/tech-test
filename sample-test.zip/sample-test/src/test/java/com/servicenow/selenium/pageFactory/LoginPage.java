package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class LoginPage {

    @FindBy(id = "username")
    public WebElement userName;

    @FindBy(id = "password")
    public WebElement password;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement authenticateButton;

    @FindBy(xpath = "//div[@id='navbar-collapse']/ul/li[3]/a/span")
    public WebElement accountSection;

    @FindBy(xpath = "//div[@id='navbar-collapse']/ul/li[3]/ul/li/a/span[2]")
    public WebElement settingsLink;

    @FindBy(xpath = "//div[@id='navbar-collapse']/ul/li[3]/ul/li[4]/a/span[2]")
    public WebElement logout;

}
