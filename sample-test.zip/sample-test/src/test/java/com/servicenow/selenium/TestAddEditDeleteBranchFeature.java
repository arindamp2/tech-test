package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.BranchAndStaffPage;
import com.servicenow.selenium.pageFactory.LoginPage;
import com.servicenow.selenium.pageFactory.WelcomePage;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

/**
 * This Test does the following
 * Log in as admin
 * Then add a new branch
 * Search the branch by branch name to make sure it's added
 * Edit it and then again search it to make sure edit worked
 * and finally delete the create branch
 *
 * Created by arindam.pattanayak on 24.03.2016.
 */
public class TestAddEditDeleteBranchFeature {

    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\test\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    final WebDriverWait wait = new WebDriverWait(driver, 10);
    private Logger log = LoggerFactory.getLogger(TestAdminLogin.class);

    @BeforeMethod
    public void logInAsAdmin() {

        String TEST_HOME_PAGE = "http://localhost:8080/";
        driver.get(TEST_HOME_PAGE);
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'login')]")));
        loginLink.click();
        // instantiate the login page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();
        manageBranchStaffData.logIn(driver, loginPage, "admin", "admin");
        log.info("Successfully logged in as ADMIN");
    }

    @Test
    public void verifyBranchAddEditDeleteFeature() throws InterruptedException {

        // Open Branch Page
        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();

        // Create a new branch first
        // Open Branch Page
        WelcomePage welcomePage = PageFactory.initElements(driver, WelcomePage.class);
        manageBranchStaffData.openBranchPage(welcomePage);


        // Now add one branch
        BranchAndStaffPage branchPage = PageFactory.initElements(driver, BranchAndStaffPage.class);
        String branchName = RandomStringUtils.randomAlphabetic(6);
        String branchCode = RandomStringUtils.randomAlphabetic(6).toUpperCase();
        manageBranchStaffData.addNewBranch(driver, branchPage, branchName, branchCode);
        log.info("New Branch Added");


        // As per functionality ID should be machine generated
//        branchPage.idField.sendKeys("123");
//        assertTrue("ID should have been read only", StringUtils.isBlank(branchPage.idField.getText()));

        manageBranchStaffData.pause();
        // Now search the newly added branch to make sure its properly added
        String actualBranchNameInSearchResult = manageBranchStaffData.searchBranchOrStaff(driver, branchPage, branchName);
        assertEquals(actualBranchNameInSearchResult, branchName, "Created Branch Name not found");

        // Now edit the branch and validate the result to make branch name has been edited successfully
        String newBranchName = RandomStringUtils.randomAlphabetic(6);
        String editedBranchName = manageBranchStaffData.editStaffOrBranch(driver, branchPage, newBranchName);
        assertEquals(editedBranchName, newBranchName, "Created Branch Name not found");



        String xPathOfBranchDeleteConfirmationButton = "//div[@id='deleteBranchConfirmation']/div/div/form/div[3]/button[2]";

        Boolean isSearchResultFoundForDeletedBranch = manageBranchStaffData.deleteStaffOrBranch(driver, branchPage,
                editedBranchName, xPathOfBranchDeleteConfirmationButton);
        // If there is search result when searched using the branch name, the row count should be zero
        assertFalse(isSearchResultFoundForDeletedBranch, "Branch was not deleted successfully");
    }



    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
