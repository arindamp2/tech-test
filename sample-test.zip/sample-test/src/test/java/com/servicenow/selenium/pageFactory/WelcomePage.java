package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class WelcomePage {
    @FindBy(xpath = "//div[@class='alert alert-success ng-scope ng-binding']")
    public WebElement welcomeTextBox;

    @FindBy(xpath = "//div[@id='navbar-collapse']/ul/li[2]/a/span/b")
    public WebElement entitiesButton;

    @FindBy(xpath = "//a[contains(@href, '#/branch')]")
    public WebElement branchLink;

    @FindBy(xpath = "//a[contains(@href, '#/staff')]")
    public WebElement staffLink;

}
