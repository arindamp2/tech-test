package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class AccountSettingsPage {


    @FindBy(xpath = "//div[@class='container']/div/div/div/div/h2")
    public WebElement header;

    @FindBy(xpath = "//input[@name='firstName']")
    public WebElement firstName;

    @FindBy(xpath = "//input[@name='lastName']")
    public WebElement lastName;

    @FindBy(xpath = "//input[@name='email']")
    public WebElement email;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement submitButton;

    @FindBy(xpath = "//div[@class='container']/div/div/div/div/div[3]")
    public WebElement accountUpdateFailureAlert;



}
