package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class RegistrationPage {

    @FindBy(xpath = "//input[@name='login']")
    public WebElement loginID;

    @FindBy(xpath = "//input[@name='email']")
    public  WebElement emaail;

    @FindBy(xpath = "//input[@name='password']")
    public WebElement password;

    @FindBy(xpath = "//input[@name='confirmPassword']")
    public WebElement confirmPassword;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement registerButton;

    @FindBy(xpath = "//div[@class='alert alert-danger ng-scope']")
    public WebElement registerFailedNotification;
}
