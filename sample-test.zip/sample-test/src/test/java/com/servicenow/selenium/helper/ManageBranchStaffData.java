package com.servicenow.selenium.helper;

import com.servicenow.selenium.pageFactory.BranchAndStaffPage;
import com.servicenow.selenium.pageFactory.LoginPage;
import com.servicenow.selenium.pageFactory.WelcomePage;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by arindam.pattanayak on 24.03.2016.
 */
public class ManageBranchStaffData {

    private static ManageBranchStaffData instance = null;

    private ManageBranchStaffData() {

    }

    public static ManageBranchStaffData getInstance() {

        if (instance == null) {
            instance = new ManageBranchStaffData();
        }
        return instance;
    }

    public String logIn(WebDriver driver, LoginPage loginPage, String username, String password) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(loginPage.userName));
        loginPage.userName.sendKeys(username);
        loginPage.password.sendKeys(password);
        loginPage.authenticateButton.click();

        WebElement welcomeTextBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='alert alert-success ng-scope ng-binding']")));
        wait.until(ExpectedConditions.visibilityOf(welcomeTextBox));

        return welcomeTextBox.getText();
    }

    public void openStaffPage(WelcomePage welcomePage) throws InterruptedException {
        welcomePage.entitiesButton.click();
        pause();
        welcomePage.staffLink.click();
    }

    public void openBranchPage(WelcomePage welcomePage) {
        welcomePage.entitiesButton.click();
        welcomePage.branchLink.click();

    }

    public void addNewBranch(WebDriver driver, BranchAndStaffPage branchOrStaffPage, String branchName, String branchCode) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        branchOrStaffPage.createNewItemButton.click();
        wait.until(ExpectedConditions.elementToBeClickable(branchOrStaffPage.nameField));

        branchOrStaffPage.nameField.sendKeys(branchName);
        branchOrStaffPage.codeField.sendKeys(branchCode);
        branchOrStaffPage.submitButton.click();
    }

    public void addNewStaff(WebDriver driver, BranchAndStaffPage staffPage, String staffName, String branchName) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        pause();
        // Now create new staff
        staffPage.createNewItemButton.click();
        wait.until(ExpectedConditions.elementToBeClickable(staffPage.nameField));
        pause();
        staffPage.nameField.sendKeys(staffName);

        staffPage.branchNameDropDown.click();
        Select select = new Select(staffPage.branchNameDropDown);
        select.selectByVisibleText(branchName);
        pause();
        staffPage.nameField.click();
        staffPage.submitButton.click();
        pause();

    }

    public String searchBranchOrStaff(WebDriver driver, BranchAndStaffPage branchAndStaffPage, String name) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        pause();
        branchAndStaffPage.searchBox.click();
        branchAndStaffPage.searchBox.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        branchAndStaffPage.searchBox.sendKeys(name);
        branchAndStaffPage.searchButton.click();

        // Refresh the Staff Page and wait until the search box is visible again and wait 2 seconds
        pause();
        branchAndStaffPage = PageFactory.initElements(driver, BranchAndStaffPage.class);
        wait.until(ExpectedConditions.elementToBeClickable(branchAndStaffPage.searchBox));
        return branchAndStaffPage.nameInSearchResult.getText();
    }


    public String editStaffOrBranch(WebDriver driver, BranchAndStaffPage branchAndStaffPage, String name) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        branchAndStaffPage.editButton.click();
        wait.until(ExpectedConditions.elementToBeClickable(branchAndStaffPage.nameField));
        branchAndStaffPage.nameField.click();
        branchAndStaffPage.nameField.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        branchAndStaffPage.nameField.sendKeys(name);

        branchAndStaffPage.submitButton.click();

        pause();
        System.out.println("Edited the Staff, now it will be searched");

        // Now search for the edited branch
        return searchBranchOrStaff(driver, branchAndStaffPage, name);
    }

    public Boolean deleteStaffOrBranch(WebDriver driver, BranchAndStaffPage branchAndStaffPage, String searchedElement, String xPathOfDeleteConfirmation) throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 10);
        branchAndStaffPage.deleteButton.click();
        driver.switchTo().activeElement();
        WebElement deleteConfirmationButton = driver.findElement(By.xpath(xPathOfDeleteConfirmation));
        wait.until(ExpectedConditions.elementToBeClickable(deleteConfirmationButton));
        deleteConfirmationButton.click();
        pause();
        wait.until(ExpectedConditions.elementToBeClickable(branchAndStaffPage.searchBox));
        // Now validate that the branch is actually deleted
        branchAndStaffPage.searchBox.click();
        branchAndStaffPage.searchBox.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        branchAndStaffPage.searchBox.sendKeys(searchedElement);
        branchAndStaffPage.searchButton.click();
        pause();

        int numberOfRows = driver.findElements(By.xpath("//div[@class='table-responsive']/table/tbody/tr")).size();
        return numberOfRows > 0;
    }

    /**
     * Sometime, WebDriverWait fails to wait until the element is visible
     * specially when there is modal dialogue or pop up appears
     * Use this method just to pause the program execution for 2 seconds
     */
    public void pause() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
