package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Both the branch and staff page have got same xpaths
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class BranchAndStaffPage {

    @FindBy(id = "searchQuery")
    public WebElement searchBox;

    @FindBy(xpath = "//form/button")
    public WebElement searchButton;

    @FindBy(xpath = "//div/div/div/button")
    public WebElement createNewItemButton;

    @FindBy(xpath = "//input[@name='id']")
    public WebElement idField;

    @FindBy(xpath = "//input[@name='name']")
    public WebElement nameField;

    @FindBy(xpath = "//input[@name='code']")
    public WebElement codeField;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement submitButton;

    @FindBy(xpath = "//div[@id='saveBranchModal']/div/div/form/div[3]/button")
    public WebElement cancelButton;

    @FindBy(xpath = "//div[@class='table-responsive']/table/tbody/tr/td[4]/button[2]")
    public WebElement editButton;

    @FindBy(xpath = "//div[@class='table-responsive']/table/tbody/tr/td[4]/button[1]")
    public WebElement viewButton;

    @FindBy(xpath = "//div[@class='table-responsive']/table/tbody/tr/td[4]/button[3]")
    public WebElement deleteButton;

    @FindBy(xpath = "//table[@class='table table-striped']/tbody/tr/td[2]")
    public WebElement nameInSearchResult;

    @FindBy(xpath = "//table[@class='table table-striped']/tbody/tr/td[3]")
    public WebElement codeInSearchResult;

    @FindBy(xpath = "//select[@name='related_branch']")
    public WebElement branchNameDropDown;

    @FindBy(xpath = "//a[contains(text(),'>')]")
    public WebElement nextPageLink;

    @FindBy(xpath = "//a[contains(text(),'>>')]")
    public WebElement lastPageLink;

    @FindBy(xpath = "//a[contains(text(),'<<')]")
    public WebElement firstPageLink;

    @FindBy(xpath = "//nav/ul/li[2]/a")
    public WebElement previousPageLink;




}

