package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.HomePage;
import com.servicenow.selenium.pageFactory.RegistrationPage;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

/**
 * This test does the following
 * Open home page
 * Then clicks on register new account link
 * add necessary information
 * then try to save it and check if the new account registration works or not
 * At the moment, this feature is broken
 * Created by arindam.pattanayak on 24.03.2016.
 */
public class TestRegisterNewAccount {

    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\test\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();
    final WebDriverWait wait = new WebDriverWait(driver, 10);


    @Test(alwaysRun = true)
    public void verifyNewAccountRegistration() {

        String TEST_HOME_PAGE = "http://localhost:8080/";
        driver.get(TEST_HOME_PAGE);
        // Instantiate Homepage
        HomePage homePage = PageFactory.initElements(driver, HomePage.class);
        WebElement registrationLink = wait.until(ExpectedConditions.elementToBeClickable(homePage.registerNewAccountLink));

        registrationLink.click();
        // Pause for 2 seconds to make sure the registration pop up appears
        manageBranchStaffData.pause();
        // instantiate the Registration page
        RegistrationPage registrationPage = PageFactory.initElements(driver, RegistrationPage.class);
        // As of now just check with lowercase
        String loginName = RandomStringUtils.randomAlphabetic(6).toLowerCase();
        String password = RandomStringUtils.randomAlphabetic(10);
        registrationPage.loginID.sendKeys(loginName);
        registrationPage.emaail.sendKeys(loginName + "@gmail.com");
        registrationPage.password.sendKeys(password);
        registrationPage.confirmPassword.sendKeys(password);
        registrationPage.registerButton.click();
        manageBranchStaffData.pause();
        assertFalse("New Account Registration is not working, The error message is : " +
                registrationPage.registerFailedNotification.getText(), registrationPage.registerFailedNotification.isDisplayed());

    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
